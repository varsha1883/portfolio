# -*- coding: utf-8 -*-
"""
Created on Sun Jan 15 17:51:56 2023

@author: varsh
"""
Trapping Rain Water


height = [0,1,0,2,1,0,1,3,2,1,2,1]

            l                   r
          

