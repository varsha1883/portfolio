# -*- coding: utf-8 -*-
"""
Created on Thu Feb  2 19:38:38 2023

@author: varsh
"""

intervals = [[0, 5], [8, 10], [15, 18]]
newInterval = [5,8]
n= len(intervals) - 1
output = [[0, 7], [8, 10], [15, 18]]
