# -*- coding: utf-8 -*-
"""
Created on Wed May 24 16:47:16 2023

@author: varsh
"""

#Others

0,1,6,8,9